import { createRoot } from 'react-dom/client';
import { App } from './ui/App';
import './styles/app.css';
import { engine } from './engine/engine';
import { startSync, compileCurrent, runLiveCode } from './store/transport';
import { installKeyboard } from './ui/keyboard';
import { getState, restoredFromAutosave, useStudio } from './store/store';
import { compileProject } from './model/compile';
import { installProjectPlugins } from './ui/fileio';

installKeyboard();
// debugging / automation hooks (used by the end-to-end tests)
(window as unknown as Record<string, unknown>).__studioDebug = { getState, useStudio, compileCurrent, runLiveCode, compileProject };
startSync();

engine
  .init()
  .then(() => {
    installProjectPlugins(getState().project);
    getState().log(restoredFromAutosave ? 'Restored your last session from autosave' : 'Loaded demo project "Sunset House" — press Space to play');
  })
  .catch((e) => getState().log('Engine failed: ' + (e?.message ?? e), 'error'));

// audio contexts need a user gesture before they can start
const resume = () => {
  engine.resume().catch(() => undefined);
};
window.addEventListener('pointerdown', resume, { capture: true });
window.addEventListener('keydown', resume, { capture: true });

createRoot(document.getElementById('root')!).render(<App />);
