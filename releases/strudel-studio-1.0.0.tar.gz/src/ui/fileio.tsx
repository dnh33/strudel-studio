import type { Project } from '../model/types';
import { getState, useStudio } from '../store/store';
import { migrateProject } from '../store/migrate';
import { createEmptyProject } from '../model/factory';
import { confirmDialog, useDialog } from './components/Menu';
import { installPlugin } from '../plugins/registry';
import { putStoredProject } from '../engine/userSamples';
import { uid } from '../model/util';
import { projectToMidi } from '../model/midifile';
import { stop } from '../store/transport';

export function download(blob: Blob, name: string) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 5000);
}

export function downloadText(text: string, name: string, type = 'text/javascript') {
  download(new Blob([text], { type }), name);
}

export async function copyText(text: string) {
  try {
    await navigator.clipboard.writeText(text);
    getState().log('Copied to clipboard');
    getState().setHint('Copied to clipboard ✓');
  } catch {
    const ta = document.createElement('textarea');
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    ta.remove();
  }
}

function toBase64Unicode(text: string) {
  const bytes = new TextEncoder().encode(text);
  let bin = '';
  for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return btoa(bin);
}

export function strudelUrl(code: string) {
  return 'https://strudel.cc/#' + encodeURIComponent(toBase64Unicode(code));
}

export function openInStrudel(code: string) {
  window.open(strudelUrl(code), '_blank', 'noopener');
}

export const safeName = (s: string) => s.replace(/[^\w\- ]+/g, '').trim().replace(/\s+/g, '_') || 'project';

// ----------------------------------------------------------- projects
export function installProjectPlugins(p: Project) {
  for (const up of p.userPlugins ?? []) {
    try {
      installPlugin(up.source, false);
    } catch (e) {
      getState().log(`Plugin "${up.name}" failed to load: ${(e as Error).message}`, 'error');
    }
  }
}

export function loadProjectGuarded(p: Project | null, fileName: string | null = null) {
  const doLoad = () => {
    stop();
    const project = p ? migrateProject(p) : createEmptyProject('Untitled');
    installProjectPlugins(project);
    getState().loadProject(project, fileName);
    getState().log(`Loaded project "${project.name}"`);
  };
  if (getState().dirty) confirmDialog('Discard changes?', 'The current project has unsaved changes. Load anyway? (It is still in the autosave until you change something.)', doLoad, 'Load');
  else doLoad();
}

export function saveProjectFile() {
  const p = getState().project;
  const name = safeName(p.name) + '.strudel-studio.json';
  downloadText(JSON.stringify(p, null, 1), name, 'application/json');
  useStudio.setState({ dirty: false, fileName: name });
}

export async function saveToBrowser() {
  const s = getState();
  const p = s.project;
  const id = (p as Project & { storeId?: string }).storeId ?? uid('pj');
  s.update((d) => {
    (d as Project & { storeId?: string }).storeId = id;
  });
  const json = JSON.stringify(getState().project);
  await putStoredProject({ id, name: p.name, updatedAt: Date.now(), json });
  useStudio.setState({ dirty: false });
  s.log(`Saved "${p.name}" to browser storage`);
  s.setHint(`Saved "${p.name}" ✓`);
}

export function openProjectFile() {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = '.json,application/json';
  input.onchange = async () => {
    const f = input.files?.[0];
    if (!f) return;
    try {
      const json = JSON.parse(await f.text());
      loadProjectGuarded(json, f.name);
    } catch (e) {
      useDialog.getState().show(
        <div className="prompt">
          <h3>Could not open file</h3>
          <p>{String((e as Error).message)}</p>
          <div className="dialog-buttons">
            <button className="primary" onClick={() => useDialog.getState().close()}>
              OK
            </button>
          </div>
        </div>,
      );
    }
  };
  input.click();
}

export function exportMidi() {
  const s = getState();
  const bytes = projectToMidi(s.project, s.mode === 'pattern' ? s.patternId : null);
  download(new Blob([bytes], { type: 'audio/midi' }), safeName(s.project.name) + (s.mode === 'pattern' ? '-pattern' : '') + '.mid');
}
